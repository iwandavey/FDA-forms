using FOQAData;
using Microsoft.VisualBasic.Devices;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Text;
using System.Windows.Forms;
using FDAClassLibrary;
using FOQA.ApplicationClasses;
using System.Reflection;

namespace FOQA
{
    /// <summary>
    /// Summary description for frmGraph.
    /// </summary>
    public class frmGraph : System.Windows.Forms.Form
    {
        private System.Windows.Forms.ImageList imgListTB;
        private System.ComponentModel.IContainer components;
        private SaveFileDialog saveFileDialog;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem mFileSave;
        private ToolStrip toolStrip;
        private ToolStripMenuItem show;
        private System.Drawing.Bitmap bmGraph;
        private ToolStripMenuItem createKMLFileToolStripMenuItem;
        private ToolStripMenuItem toolsToolStripMenuItem;
        private ToolStripMenuItem CalculateDistanceToolStripMenu;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem setStartCounterToolStripMenuItem;
        private ToolStripMenuItem setEndCounterToolStripMenuItem;
        private ToolStripMenuItem createKMLToolStripMenuItem;
        private ToolStripMenuItem showDistanceResultsToolStripMenuItem;
        private ToolStripMenuItem CalculateFuelBurned;
        private ToolStripMenuItem positionToolStripMenuItem;
        private ToolStripMenuItem savePositionToolStripMenuItem;
        private ToolStripMenuItem touchdownToolStripMenuItem;
        private ToolStripMenuItem turnoffToolStripMenuItem;
        private TableLayoutPanel tableLayoutPanel1;
        private ToolStripMenuItem gotoToolStripMenuItem;
        private ToolStripMenuItem nextLandingToolStripMenuItem;
        private ToolStripMenuItem placeTextToolStripMenuItem;
        private ToolStripTextBox placeTextToolStripTextBox;
        private ToolStripMenuItem noteCoulorToolStripMenuItem;
        private ToolStripTextBox noteTextToolStripTextBox;
        private ColorDialog colorDialog;
        private Panel pnlGraph;
        private DataGridView dataGridView1;
        private TrackBar trkScaleH;
        private HScrollBar schGraphPos;
        private TextBox tLatAndLong;
        private Label lblAP;
        private Label lblTAT;
        private ToolStripMenuItem showGraphParametersToolStripMenuItem;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel Datum;
        private ToolStripStatusLabel vlugNommer;
        private ToolStripStatusLabel Gebeurtenis;
        private ToolStripStatusLabel Merker;
        private ToolStripStatusLabel skermHoogte;
        private ToolStripStatusLabel skermAGMerker;
        private ToolStripStatusLabel distansieVanAG;
        private ToolStripMenuItem positionOnGoogle;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
        private ToolStripStatusLabel beginCounter;
        private ToolStripStatusLabel eindCounter;
        private CDI.LineControl.Line line19;

        public frmGraph()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGraph));
            this.imgListTB = new System.Windows.Forms.ImageList(this.components);
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.createKMLFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.show = new System.Windows.Forms.ToolStripMenuItem();
            this.showGraphParametersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.positionOnGoogle = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CalculateDistanceToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.createKMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showDistanceResultsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CalculateFuelBurned = new System.Windows.Forms.ToolStripMenuItem();
            this.gotoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nextLandingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noteCoulorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noteTextToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.setStartCounterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setEndCounterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.positionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.savePositionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.touchdownToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.turnoffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.placeTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.placeTextToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pnlGraph = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.trkScaleH = new System.Windows.Forms.TrackBar();
            this.schGraphPos = new System.Windows.Forms.HScrollBar();
            this.tLatAndLong = new System.Windows.Forms.TextBox();
            this.lblAP = new System.Windows.Forms.Label();
            this.lblTAT = new System.Windows.Forms.Label();
            this.line19 = new CDI.LineControl.Line();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.Datum = new System.Windows.Forms.ToolStripStatusLabel();
            this.vlugNommer = new System.Windows.Forms.ToolStripStatusLabel();
            this.Gebeurtenis = new System.Windows.Forms.ToolStripStatusLabel();
            this.Merker = new System.Windows.Forms.ToolStripStatusLabel();
            this.skermHoogte = new System.Windows.Forms.ToolStripStatusLabel();
            this.skermAGMerker = new System.Windows.Forms.ToolStripStatusLabel();
            this.distansieVanAG = new System.Windows.Forms.ToolStripStatusLabel();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.beginCounter = new System.Windows.Forms.ToolStripStatusLabel();
            this.eindCounter = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.pnlGraph.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkScaleH)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // imgListTB
            // 
            this.imgListTB.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgListTB.ImageStream")));
            this.imgListTB.TransparentColor = System.Drawing.Color.Transparent;
            this.imgListTB.Images.SetKeyName(0, "");
            this.imgListTB.Images.SetKeyName(1, "");
            this.imgListTB.Images.SetKeyName(2, "");
            this.imgListTB.Images.SetKeyName(3, "");
            this.imgListTB.Images.SetKeyName(4, "");
            this.imgListTB.Images.SetKeyName(5, "");
            this.imgListTB.Images.SetKeyName(6, "");
            this.imgListTB.Images.SetKeyName(7, "");
            this.imgListTB.Images.SetKeyName(8, "");
            this.imgListTB.Images.SetKeyName(9, "");
            this.imgListTB.Images.SetKeyName(10, "");
            this.imgListTB.Images.SetKeyName(11, "");
            this.imgListTB.Images.SetKeyName(12, "");
            this.imgListTB.Images.SetKeyName(13, "");
            this.imgListTB.Images.SetKeyName(14, "");
            this.imgListTB.Images.SetKeyName(15, "");
            this.imgListTB.Images.SetKeyName(16, "");
            this.imgListTB.Images.SetKeyName(17, "");
            this.imgListTB.Images.SetKeyName(18, "");
            this.imgListTB.Images.SetKeyName(19, "");
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Filter = "jpg Files |* .jpg";
            this.saveFileDialog.Title = "Save jpg image of the graph.";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.show,
            this.toolsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1495, 24);
            this.menuStrip1.TabIndex = 92;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mFileSave,
            this.createKMLFileToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // mFileSave
            // 
            this.mFileSave.Image = ((System.Drawing.Image)(resources.GetObject("mFileSave.Image")));
            this.mFileSave.Name = "mFileSave";
            this.mFileSave.Size = new System.Drawing.Size(154, 22);
            this.mFileSave.Text = "&Save";
            this.mFileSave.ToolTipText = "Save an image of the graph.";
            this.mFileSave.Click += new System.EventHandler(this.mFileSave_Click);
            // 
            // createKMLFileToolStripMenuItem
            // 
            this.createKMLFileToolStripMenuItem.Name = "createKMLFileToolStripMenuItem";
            this.createKMLFileToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.createKMLFileToolStripMenuItem.Text = "Create KML file";
            this.createKMLFileToolStripMenuItem.ToolTipText = "Create a file you can view in google earth.";
            this.createKMLFileToolStripMenuItem.Click += new System.EventHandler(this.createKMLFileToolStripMenuItem_Click);
            // 
            // show
            // 
            this.show.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showGraphParametersToolStripMenuItem,
            this.positionOnGoogle});
            this.show.Name = "show";
            this.show.Size = new System.Drawing.Size(48, 20);
            this.show.Text = "Show";
            this.show.ToolTipText = "Shown after the alt value in [] brackets.";
            // 
            // showGraphParametersToolStripMenuItem
            // 
            this.showGraphParametersToolStripMenuItem.Name = "showGraphParametersToolStripMenuItem";
            this.showGraphParametersToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.showGraphParametersToolStripMenuItem.Text = "Graph parameters";
            this.showGraphParametersToolStripMenuItem.Click += new System.EventHandler(this.showGraphParametersToolStripMenuItem_Click);
            // 
            // positionOnGoogle
            // 
            this.positionOnGoogle.Name = "positionOnGoogle";
            this.positionOnGoogle.Size = new System.Drawing.Size(175, 22);
            this.positionOnGoogle.Text = "Position on Google";
            this.positionOnGoogle.Click += new System.EventHandler(this.positionOnGoogle_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CalculateDistanceToolStripMenu,
            this.createKMLToolStripMenuItem,
            this.showDistanceResultsToolStripMenuItem,
            this.CalculateFuelBurned,
            this.gotoToolStripMenuItem,
            this.noteCoulorToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.toolsToolStripMenuItem.Text = "Tools";
            this.toolsToolStripMenuItem.ToolTipText = "Calculate distance between two caounter positions.";
            // 
            // CalculateDistanceToolStripMenu
            // 
            this.CalculateDistanceToolStripMenu.Name = "CalculateDistanceToolStripMenu";
            this.CalculateDistanceToolStripMenu.Size = new System.Drawing.Size(191, 22);
            this.CalculateDistanceToolStripMenu.Text = "Calculate Distance";
            this.CalculateDistanceToolStripMenu.Click += new System.EventHandler(this.CalculateDistanceToolStripMenu_Click);
            // 
            // createKMLToolStripMenuItem
            // 
            this.createKMLToolStripMenuItem.Name = "createKMLToolStripMenuItem";
            this.createKMLToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.createKMLToolStripMenuItem.Text = "Create KML";
            this.createKMLToolStripMenuItem.ToolTipText = "Create a file to view in Google Earth.";
            this.createKMLToolStripMenuItem.Click += new System.EventHandler(this.createKMLToolStripMenuItem_Click);
            // 
            // showDistanceResultsToolStripMenuItem
            // 
            this.showDistanceResultsToolStripMenuItem.Name = "showDistanceResultsToolStripMenuItem";
            this.showDistanceResultsToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.showDistanceResultsToolStripMenuItem.Text = "Show Distance results.";
            this.showDistanceResultsToolStripMenuItem.Click += new System.EventHandler(this.showDistanceResultsToolStripMenuItem_Click);
            // 
            // CalculateFuelBurned
            // 
            this.CalculateFuelBurned.Name = "CalculateFuelBurned";
            this.CalculateFuelBurned.Size = new System.Drawing.Size(191, 22);
            this.CalculateFuelBurned.Text = "Calculate Fuel";
            this.CalculateFuelBurned.ToolTipText = "Calculate the fuel burned between selected points.";
            this.CalculateFuelBurned.Click += new System.EventHandler(this.CalculateFuelBurned_Click);
            // 
            // gotoToolStripMenuItem
            // 
            this.gotoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nextLandingToolStripMenuItem});
            this.gotoToolStripMenuItem.Name = "gotoToolStripMenuItem";
            this.gotoToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.gotoToolStripMenuItem.Text = "Goto";
            // 
            // nextLandingToolStripMenuItem
            // 
            this.nextLandingToolStripMenuItem.Name = "nextLandingToolStripMenuItem";
            this.nextLandingToolStripMenuItem.Size = new System.Drawing.Size(67, 22);
            // 
            // noteCoulorToolStripMenuItem
            // 
            this.noteCoulorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.noteTextToolStripTextBox});
            this.noteCoulorToolStripMenuItem.Name = "noteCoulorToolStripMenuItem";
            this.noteCoulorToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.noteCoulorToolStripMenuItem.Text = "Note Color";
            this.noteCoulorToolStripMenuItem.Click += new System.EventHandler(this.noteCoulorToolStripMenuItem_Click);
            // 
            // noteTextToolStripTextBox
            // 
            this.noteTextToolStripTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.noteTextToolStripTextBox.Name = "noteTextToolStripTextBox";
            this.noteTextToolStripTextBox.Size = new System.Drawing.Size(100, 23);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setStartCounterToolStripMenuItem,
            this.setEndCounterToolStripMenuItem,
            this.positionToolStripMenuItem,
            this.placeTextToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(181, 114);
            // 
            // setStartCounterToolStripMenuItem
            // 
            this.setStartCounterToolStripMenuItem.Name = "setStartCounterToolStripMenuItem";
            this.setStartCounterToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.setStartCounterToolStripMenuItem.Text = "Set Start Counter";
            this.setStartCounterToolStripMenuItem.Click += new System.EventHandler(this.setStartCounterToolStripMenuItem_Click);
            // 
            // setEndCounterToolStripMenuItem
            // 
            this.setEndCounterToolStripMenuItem.Name = "setEndCounterToolStripMenuItem";
            this.setEndCounterToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.setEndCounterToolStripMenuItem.Text = "Set End Counter";
            this.setEndCounterToolStripMenuItem.Click += new System.EventHandler(this.setEndCounterToolStripMenuItem_Click);
            // 
            // positionToolStripMenuItem
            // 
            this.positionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.savePositionToolStripMenuItem,
            this.touchdownToolStripMenuItem,
            this.turnoffToolStripMenuItem});
            this.positionToolStripMenuItem.Name = "positionToolStripMenuItem";
            this.positionToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.positionToolStripMenuItem.Text = "Touchdown";
            // 
            // savePositionToolStripMenuItem
            // 
            this.savePositionToolStripMenuItem.Name = "savePositionToolStripMenuItem";
            this.savePositionToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.savePositionToolStripMenuItem.Text = "Flare";
            this.savePositionToolStripMenuItem.Click += new System.EventHandler(this.savePositionToolStripMenuItem_Click);
            // 
            // touchdownToolStripMenuItem
            // 
            this.touchdownToolStripMenuItem.Name = "touchdownToolStripMenuItem";
            this.touchdownToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.touchdownToolStripMenuItem.Text = "Touchdown";
            // 
            // turnoffToolStripMenuItem
            // 
            this.turnoffToolStripMenuItem.Name = "turnoffToolStripMenuItem";
            this.turnoffToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.turnoffToolStripMenuItem.Text = "Turnoff";
            // 
            // placeTextToolStripMenuItem
            // 
            this.placeTextToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.placeTextToolStripTextBox});
            this.placeTextToolStripMenuItem.Name = "placeTextToolStripMenuItem";
            this.placeTextToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.placeTextToolStripMenuItem.Text = "Place Text";
            // 
            // placeTextToolStripTextBox
            // 
            this.placeTextToolStripTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.placeTextToolStripTextBox.Name = "placeTextToolStripTextBox";
            this.placeTextToolStripTextBox.Size = new System.Drawing.Size(100, 23);
            // 
            // toolStrip
            // 
            this.toolStrip.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.toolStrip.AutoSize = false;
            this.toolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip.ImageScalingSize = new System.Drawing.Size(38, 38);
            this.toolStrip.Location = new System.Drawing.Point(0, 24);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(1495, 25);
            this.toolStrip.TabIndex = 12454;
            this.toolStrip.Text = "toolStrip1";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.pnlGraph, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 52);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1495, 676);
            this.tableLayoutPanel1.TabIndex = 12455;
            // 
            // pnlGraph
            // 
            this.pnlGraph.AutoSize = true;
            this.pnlGraph.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlGraph.BackColor = System.Drawing.Color.White;
            this.pnlGraph.ContextMenuStrip = this.contextMenuStrip1;
            this.pnlGraph.Controls.Add(this.dataGridView1);
            this.pnlGraph.Controls.Add(this.trkScaleH);
            this.pnlGraph.Controls.Add(this.schGraphPos);
            this.pnlGraph.Controls.Add(this.tLatAndLong);
            this.pnlGraph.Controls.Add(this.lblAP);
            this.pnlGraph.Controls.Add(this.lblTAT);
            this.pnlGraph.Controls.Add(this.line19);
            this.pnlGraph.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlGraph.ForeColor = System.Drawing.Color.Black;
            this.pnlGraph.Location = new System.Drawing.Point(3, 3);
            this.pnlGraph.Name = "pnlGraph";
            this.pnlGraph.Size = new System.Drawing.Size(1489, 670);
            this.pnlGraph.TabIndex = 62;
            this.pnlGraph.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlGraph_MouseDown);
            this.pnlGraph.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlGraph_MouseMove);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(1216, 40);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(270, 627);
            this.dataGridView1.TabIndex = 12489;
            this.dataGridView1.Visible = false;
            // 
            // trkScaleH
            // 
            this.trkScaleH.AutoSize = false;
            this.trkScaleH.BackColor = System.Drawing.SystemColors.Control;
            this.trkScaleH.LargeChange = 2;
            this.trkScaleH.Location = new System.Drawing.Point(1094, 7);
            this.trkScaleH.Maximum = 80;
            this.trkScaleH.Minimum = 1;
            this.trkScaleH.Name = "trkScaleH";
            this.trkScaleH.Size = new System.Drawing.Size(128, 27);
            this.trkScaleH.SmallChange = 2;
            this.trkScaleH.TabIndex = 90;
            this.trkScaleH.TickFrequency = 2;
            this.trkScaleH.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trkScaleH.Value = 50;
            this.trkScaleH.ValueChanged += new System.EventHandler(this.trkScaleH_ValueChanged);
            // 
            // schGraphPos
            // 
            this.schGraphPos.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.schGraphPos.LargeChange = 101;
            this.schGraphPos.Location = new System.Drawing.Point(807, 10);
            this.schGraphPos.Name = "schGraphPos";
            this.schGraphPos.Size = new System.Drawing.Size(269, 20);
            this.schGraphPos.SmallChange = 101;
            this.schGraphPos.TabIndex = 1;
            this.schGraphPos.TabStop = true;
            this.schGraphPos.Scroll += new System.Windows.Forms.ScrollEventHandler(this.schGraphPos_Scroll);
            this.schGraphPos.ValueChanged += new System.EventHandler(this.schGraphPos_ValueChanged);
            // 
            // tLatAndLong
            // 
            this.tLatAndLong.Location = new System.Drawing.Point(72, 7);
            this.tLatAndLong.Name = "tLatAndLong";
            this.tLatAndLong.Size = new System.Drawing.Size(306, 20);
            this.tLatAndLong.TabIndex = 12456;
            this.tLatAndLong.Visible = false;
            // 
            // lblAP
            // 
            this.lblAP.AutoSize = true;
            this.lblAP.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAP.Location = new System.Drawing.Point(8, 280);
            this.lblAP.Name = "lblAP";
            this.lblAP.Size = new System.Drawing.Size(0, 14);
            this.lblAP.TabIndex = 12452;
            // 
            // lblTAT
            // 
            this.lblTAT.AutoSize = true;
            this.lblTAT.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTAT.Location = new System.Drawing.Point(6, 10);
            this.lblTAT.Name = "lblTAT";
            this.lblTAT.Size = new System.Drawing.Size(51, 14);
            this.lblTAT.TabIndex = 12450;
            this.lblTAT.Text = "TAT 39.9";
            this.lblTAT.Visible = false;
            // 
            // line19
            // 
            this.line19.GradientDirection = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.line19.LineColor1 = System.Drawing.Color.Black;
            this.line19.LineColor2 = System.Drawing.Color.Black;
            this.line19.LineDirection = CDI.LineControl.LineDirections.Vertical;
            this.line19.Location = new System.Drawing.Point(41, 0);
            this.line19.Name = "line19";
            this.line19.Size = new System.Drawing.Size(1, 1000);
            this.line19.TabIndex = 65;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.statusStrip1.AutoSize = false;
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Datum,
            this.vlugNommer,
            this.Gebeurtenis,
            this.Merker,
            this.skermHoogte,
            this.skermAGMerker,
            this.distansieVanAG,
            this.beginCounter,
            this.eindCounter});
            this.statusStrip1.Location = new System.Drawing.Point(3, 731);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1492, 22);
            this.statusStrip1.TabIndex = 12456;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // Datum
            // 
            this.Datum.AutoSize = false;
            this.Datum.Name = "Datum";
            this.Datum.Size = new System.Drawing.Size(110, 17);
            this.Datum.Text = "20 Jan 2022";
            // 
            // vlugNommer
            // 
            this.vlugNommer.AutoSize = false;
            this.vlugNommer.Name = "vlugNommer";
            this.vlugNommer.Size = new System.Drawing.Size(40, 17);
            this.vlugNommer.Text = "665";
            // 
            // Gebeurtenis
            // 
            this.Gebeurtenis.AutoSize = false;
            this.Gebeurtenis.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Gebeurtenis.Name = "Gebeurtenis";
            this.Gebeurtenis.Size = new System.Drawing.Size(200, 17);
            this.Gebeurtenis.Text = "Low N1 on final approach.";
            // 
            // Merker
            // 
            this.Merker.AutoSize = false;
            this.Merker.Name = "Merker";
            this.Merker.Size = new System.Drawing.Size(40, 17);
            // 
            // skermHoogte
            // 
            this.skermHoogte.AutoSize = false;
            this.skermHoogte.Name = "skermHoogte";
            this.skermHoogte.Size = new System.Drawing.Size(60, 17);
            this.skermHoogte.Text = "10500";
            // 
            // skermAGMerker
            // 
            this.skermAGMerker.AutoSize = false;
            this.skermAGMerker.Name = "skermAGMerker";
            this.skermAGMerker.Size = new System.Drawing.Size(70, 17);
            this.skermAGMerker.Text = "983145";
            // 
            // distansieVanAG
            // 
            this.distansieVanAG.AutoSize = false;
            this.distansieVanAG.Name = "distansieVanAG";
            this.distansieVanAG.Size = new System.Drawing.Size(140, 17);
            this.distansieVanAG.Text = "10 km";
            this.distansieVanAG.ToolTipText = "Distance from the last touchdown / airborn point that was on screen.";
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // beginCounter
            // 
            this.beginCounter.Name = "beginCounter";
            this.beginCounter.Size = new System.Drawing.Size(17, 17);
            this.beginCounter.Text = "--";
            // 
            // eindCounter
            // 
            this.eindCounter.Name = "eindCounter";
            this.eindCounter.Size = new System.Drawing.Size(17, 17);
            this.eindCounter.Text = "--";
            // 
            // frmGraph
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1495, 753);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.toolStrip);
            this.Controls.Add(this.menuStrip1);

            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmGraph";
            this.Text = "Graph";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmGraph_Load);
            this.Shown += new System.EventHandler(this.frmGraph_Load);
            this.ResizeEnd += new System.EventHandler(this.frmGraph_Load);
            this.SizeChanged += new System.EventHandler(this.frmGraph_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmGraph_KeyDown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.pnlGraph.ResumeLayout(false);
            this.pnlGraph.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkScaleH)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        #region veranderlikes
        public bool tekenBeginMerkerLyn { get; set; }
        private static DataTable CSV = new DataTable();
        public int beginMerkerPosiesie
                  , drawStartPos
                  , iCount = 0;

        private double huidigeCounter = 0;

        public int opSkermHoogte = -5000;
        public double opSkermLandOpstuigMerker;

        public double startPos;
        private int iPos = 0;

        private static int CSVRowCount = 0;
        private static float bottomVal = 0;
        private static float topVal = 0;
        private static float constant = 0;
        private static double scale;
        private static Color noteColor = Color.Black;
        //private bool kiesLysGeStel = false;
        public bool vinnigeKnoppiesGestel = false;
        public bool plotWaardesGestel { get; set; } = false;
        private List<PlotParameters> p = new List<PlotParameters>();

        #endregion
        private void pnlGraph_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            line19.Location = new Point(MousePosition.X - (ActiveForm.Left + 11), 0);
            ShowBM();
        }
        private void addWarningsToolDropDownItems()
        {
            //ToolStripMenuItem[] mi = new ToolStripMenuItem[csv.Warnings.Count];

            //for (int i = 0; i < mi.Length; i++)
            //{
            //    mi[i] = new ToolStripMenuItem();
            //    mi[i].Name = csv.Warnings[i];
            //    mi[i].CheckOnClick = true;
            //    mi[i].Text = csv.Warnings[i]; ;
            //    mi[i].Click += new EventHandler(warningMenuItem_Click);
            //}

            //if (!kiesLysGeStel)
            //{
            //    warningsToolStripMenuItem.DropDownItems.AddRange(mi);
            //    kiesLysGeStel = true;
            //}

        }
        private void CalculateDistanceToolStripMenu_Click(object sender, EventArgs e)
        {
            Tools.CalculateDistance(CSV);
            StatusBar();

            MessageBox.Show("Distance " + Math.Round(Tools.Distance, 3) + " Km / " + " NM " + Math.Round(Tools.Distance * 3280 / 6080, 3) + " Burn " + Tools.FU + " kg.", "Distance", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void CalculateFuelBurned_Click(object sender, EventArgs e)
        {
            double FuelBurn = 0;
            double FuelBurnGW = 0;

            try
            {
                FOQAData.Tools.CalculateFuelBurnedBetweenPoints(CSV, out FuelBurn, out FuelBurnGW);
                FuelBurn = csv.setFuelUnit(FuelBurn); // TODO : check this for lbs fuel units

                MessageBox.Show("The Fuel burn calculated per second using fuel flow " + Math.Round(FuelBurn, 1).ToString() + " kg, fuel burn calculated difference between GW " + FuelBurnGW + " kg.",
                    "Fuel burn", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception xx)
            {
                MessageBox.Show("Error " + xx, "Oops", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void createKMLFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            createKML m = new createKML();
            m.KMLEventCounter = Convert.ToInt32(FOQAData.csv.sEXCcounter);
            m.Show();
        }
        private void BerekenAfstandPerSekMetode(double merker, int pos)
        {


            int tel = 0;

            if (opSkermLandOpstuigMerker < merker)
            {
                tel = -1;
            }
            else
            {
                tel = 1;
            }
            double TotalDistance = 0;
            for (int i = 0; i < CSV.Rows.Count && i > (pos * -1); i += tel)
            {
                double.TryParse(CSV.Rows[pos + i][Parameters.rowCounter].ToString(), out double x);

                double GroundSpeed = Convert.ToDouble(CSV.Rows[pos + i][Parameters.speedGround]);
                //FU += ((Convert.ToDouble(dt.Rows[i][csv.eng1FuelFlow])) + (Convert.ToDouble(dt.Rows[i][csv.eng2FuelFlow]))) / 3600;
                double DistanceTraveledInMPS = (((GroundSpeed * 6076.12) / 3280) / 3600);
                TotalDistance += DistanceTraveledInMPS;

                //todo hierdie gaan nie werk as ek later met desimale counter posies werk nie.

                if (opSkermLandOpstuigMerker == x)
                {

                    distansieVanAG.Text = Math.Round(TotalDistance, 2) + " km | " + Math.Round(TotalDistance * 0.53947368421052631578947368421, 2) + " NM";
                    return;
                }

            }



        }
        private void DrawBM()
        {
            int iy1,
                iy2,

                Height,
                iCCount = 0;

            //double linePos;
            float h1 = 0;
            float h2 = 0;
            double[,] wind = new double[2, 2];
            double[] radioAlt = new double[2];
            double[] DME = new double[2];

            int[] iAP = new int[] { 0, 0, 0, 0 };

            float[] glideSlope = new float[2];

            string sLabel;

            Cursor.Current = Cursors.WaitCursor;

            Graphics objGraphics;
            objGraphics = Graphics.FromImage(bmGraph);

            objGraphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            objGraphics.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
            objGraphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBilinear;
            // This is to check the counter count that will = time.
            try
            {
                Pen lpen = new Pen(Color.Blue, 1);
                Pen fpen = new Pen(Color.Green, 2);
                Font fnt = new Font("Tahoma", 8, FontStyle.Bold);
                SolidBrush sbLedger = new SolidBrush(Color.Black);
                objGraphics.Clear(Color.White);

                DrawScale();

                IList<string> Para = new List<string>();
                IList<Color> colors = new List<Color>();

                //top shift 4
                //bottom shift 7

                #region hide
                Para.Clear();
                colors.Clear();

                Height = pnlGraph.Height;
                scale = trkScaleH.Value * 0.05;

                drawStartPos = schGraphPos.Value;

                double widthCount = pnlGraph.Width / scale;
                int count = 0;

                KryOpstygLandWaardes(widthCount, schGraphPos.Value);

                float.TryParse(scale.ToString(), out float res1);

                //todo garmin frames
                #region teken message garnim
                //if (messagesToolStripMenuItem.Checked || csv.messageText != "")
                //{
                //    count = 0;
                //    h1 = 0;

                //    Para.Add("Messages");
                //    lpen.Color = Color.Orange;
                //    colors.Add(lpen.Color);

                //    iy1 = (int)(Height - (Height * 0.64f));

                //    for (int i = drawStartPos; i < CSVRowCount && count < widthCount; i++)
                //    {
                //        iCCount++;
                //        string s = CSV.Rows[i][csv.messageText].ToString();
                //        if (s != "")
                //        {
                //            objGraphics.DrawEllipse(lpen, h1, iy1 - 3, 5, 5);
                //        }

                //        h1 += res1;

                //    } // counter values
                //}
                #endregion
                #endregion
                #region Altitude pressure old
                //count = 0;
                //h1 = 0;
                //h2 = res1;

                //Para.Add("press Alt");
                //lpen.Color = Color.Blue;
                //colors.Add(lpen.Color);

                //for (int i = drawStartPos; i < CSVRowCount - 10 && count < widthCount; i++) // AltitudeP
                //{
                //    count++;

                //    double.TryParse(CSV.Rows[i][Parameters.altitudePressure].ToString(), out double a);//die twee is nuut
                //    double.TryParse(CSV.Rows[i + 1][Parameters.altitudePressure].ToString(), out double b);
                //    iy1 = (int)(Height - ((Height * 0.036f) + ((Height * 0.036f) * ((float)a / 500))));
                //    iy2 = (int)(Height - ((Height * 0.036f) + ((Height * 0.036f) * ((float)b / 500))));
                //    objGraphics.DrawLine(lpen, h1, iy1, h2, iy2);

                //    h1 += res1;
                //    h2 += res1;
                //}
                #endregion

                #region Teken die waardes.
                int waardeWatGeplotMoetWordTel = 0;

                for (int t = 0; t < p.Count; t++)
                {
                    count = 0;
                    h1 = 0;
                    h2 = res1;

                    drawStartPos = schGraphPos.Value;

                    if (p[t].teken == true && p[t].tekenTipe.ToLower() == "grafiek")
                    {
                        Para.Add(p[t].waardeOmTePlot);
                        lpen.Color = p[t].kleur;
                        colors.Add(lpen.Color);

                        for (int i = drawStartPos; i < CSVRowCount - 10 && count < widthCount; i++) // AltitudeP
                        {
                            count++;
                            double a;
                            double b;
                            // teken merker lyn.

                            if (p[t].waardeOmTePlot.ToLower() == "daalspoed")//berekende waardes
                            {
                                if (i < 3)
                                {
                                    a = 0;
                                    b = 0;
                                }
                                else
                                {
                                    double.TryParse(CSV.Rows[i - 3][Parameters.altitudePressure].ToString(), out double een);//die twee is nuut
                                    double.TryParse(CSV.Rows[i + 3][Parameters.altitudePressure].ToString(), out double twee);
                                    double.TryParse(CSV.Rows[i - 2][Parameters.altitudePressure].ToString(), out double drie);
                                    double.TryParse(CSV.Rows[i + 4][Parameters.altitudePressure].ToString(), out double vier);
                                    a = (twee - een) * 10;
                                    b = (vier - drie) * 10;
                                }
                            }
                            else
                            {
                                double.TryParse(CSV.Rows[i][p[t].waardeOmTePlot].ToString(), out a);//die twee is nuut
                                double.TryParse(CSV.Rows[i + 1][p[t].waardeOmTePlot].ToString(), out b);
                            }

                            iy1 = (int)(Height - ((p[t].posisie + (bottomVal * p[t].skuif)) + (constant * ((float)(a / p[t].faktor)))));
                            iy2 = (int)(Height - ((p[t].posisie + (bottomVal * p[t].skuif)) + (constant * ((float)(b / p[t].faktor)))));

                            objGraphics.DrawLine(lpen, h1, iy1, h2, iy2);

                            h1 += res1;
                            h2 += res1;
                        }
                    }

                    if (p[t].teken == true && p[t].tekenTipe.ToLower() == "waarde")
                    {

                        int interval = (int)widthCount / 10;

                        iCCount = 0;

                        for (int i = drawStartPos; i < CSVRowCount && count < widthCount; i++)
                        {
                            iy1 = (int)(Height - (Height * 0.64f));

                            iCCount++;

                            double.TryParse(CSV.Rows[i][Parameters.rowCounter].ToString(), out double ryMerker);
                            double.TryParse(CSV.Rows[i][p[t].waardeOmTePlot].ToString(), out double counter);

                            if (iCCount == interval)
                            {
                                iy1 -= waardeWatGeplotMoetWordTel * 13;
                                //sLabel = Math.Round(counter, 1).ToString();
                                sLabel = CSV.Rows[i][p[t].waardeOmTePlot].ToString();
                                lpen.Color = Color.Black;
                                if (waardeWatGeplotMoetWordTel == 0)
                                {
                                    objGraphics.DrawLine(lpen, h1 - 2, iy1, h1 - 2, iy1 + 15);
                                }

                                objGraphics.DrawString(sLabel, fnt, new SolidBrush(Color.Black), h1 + 2, iy1 + 10);
                                iCCount = 0;
                            }
                            if (ryMerker == beginMerkerPosiesie && tekenBeginMerkerLyn)
                            {// todo maak dat die lyn getrek word vir al die exceedances....

                                lpen.Color = Color.Magenta;
                                objGraphics.DrawLine(lpen
                                                    , h1 - 2
                                                    , (float)30
                                                    , h1 - 2
                                                    , pnlGraph.Height - 30);
                            }

                            h1 += res1;
                        } // counter values

                        waardeWatGeplotMoetWordTel += 1;
                    }
                }

                #endregion

                #region check if warning was checked
                //int yi = 0;

                //foreach (ToolStripMenuItem item in warningsToolStripMenuItem.DropDownItems)
                //{

                //    if (item.Checked)
                //    {
                //        count = 0;
                //        h1 = 0;

                //        Para.Add(item.Name);

                //        if (yi == 0)
                //        {
                //            lpen.Color = Color.DarkRed;
                //        }
                //        else if (yi == 10)
                //        {
                //            lpen.Color = Color.DarkOrange;
                //        }
                //        else if (yi == 20)
                //        {
                //            lpen.Color = Color.Red;
                //        }
                //        else if (yi == 30)
                //        {
                //            lpen.Color = Color.Orange;
                //        }
                //        else if (yi == 40)
                //        {
                //            lpen.Color = Color.Gold;
                //        }
                //        else
                //        {
                //            lpen.Color = Color.Black;
                //        }


                //        lpen.Width = 3;

                //        colors.Add(lpen.Color);

                //        iy1 = (int)((Height - (Height * 0.64f)) + 20 + yi);

                //        for (int i = drawStartPos; i < CSVRowCount && count < widthCount; i++)
                //        {
                //            iCCount++;
                //            string s = CSV.Rows[i][item.Name].ToString();

                //            if (s == "1")
                //            {
                //                objGraphics.DrawLine(lpen, h1 - 2, iy1, h1 - 2, iy1 + 8);
                //            }

                //            h1 += res1;

                //        } // counter values
                //        yi += 10;
                //    }

                //}

                #endregion

                #region ledger
                // hier skyf ek die ledger
                //int LedgerWidth = (int)(ClientSize.Width * 0.2f);
                int LedgerWidth = 50;
                int LedgerCount = 1;
                int LedgerHeight = 5;
                for (int i = 0; i < Para.Count; i++)
                {
                    sbLedger.Color = colors[i];
                    objGraphics.DrawString(Para[i], fnt, sbLedger, LedgerWidth, LedgerHeight);
                    LedgerHeight += 10;
                    LedgerCount += 1;
                    if (LedgerCount % 5 == 0)
                    {
                        LedgerWidth += 100;
                        LedgerCount = 1;
                        LedgerHeight = 5;

                    }
                }
                #endregion
            }
            catch (IndexOutOfRangeException)
            { }
            catch (Exception ee)
            {
                Cursor.Current = Cursors.Arrow;
                MessageBox.Show(ee.ToString(), " Paint Line", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                objGraphics.Dispose();
            }

            Cursor.Current = Cursors.Arrow;

        }
        private void DrawScale()
        {
            //int iAlt = 0, h1, h2;
            //float fy;
            string sValue = "0";

            Cursor.Current = Cursors.WaitCursor;

            Graphics objGraphics;
            objGraphics = Graphics.FromImage(bmGraph);

            try
            {
                Pen lpen = new Pen(Color.LightGray, 1);
                objGraphics.Clear(Color.White);

                int h1 = 35;
                int h2 = pnlGraph.Width - 35;
                float fy = pnlGraph.Height;
                int iAlt = -500;
                int iVSI = -4000;
                for (int i = 0; i < 17; i++)
                {
                    sValue = iAlt.ToString();
                    objGraphics.DrawLine(lpen, h1, fy, h2, fy);
                    objGraphics.DrawString(sValue, new Font("Aerial", 10), new SolidBrush(Color.Black), 0, fy - 7);
                    objGraphics.DrawString(iVSI.ToString(), new Font("Aerial", 10), new SolidBrush(Color.Black), pnlGraph.Width - 35, fy - 7);
                    fy -= (pnlGraph.Height * 0.036f);
                    iVSI += 500;
                    iAlt += 500;
                }
                // Teken die grafiek labels (onderste)

                fy = pnlGraph.Height * 0.33f;
                iAlt = 0;
                iVSI = 4;
                for (int i = 0; i < 8; i++)
                {
                    sValue = iAlt.ToString();
                    objGraphics.DrawLine(lpen, h1, fy, h2, fy);
                    objGraphics.DrawString(sValue, new Font("Tahoma", 10), new SolidBrush(Color.Black), 0, fy - 7);
                    objGraphics.DrawString(iVSI.ToString(), new Font("Aerial", 10), new SolidBrush(Color.Black), pnlGraph.Width - 35, fy - 7);
                    iVSI -= 1;
                    fy -= (pnlGraph.Height * 0.036f);
                    iAlt += 50;
                }



                objGraphics.Dispose();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString(), " Paint Line", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Arrow;
            }
            Cursor.Current = Cursors.Arrow;

        }
        private void frmGraph_KeyDown(object sender, KeyEventArgs e)
        {
            int pw = (int)((pnlGraph.Width / scale) / 2);
            int a = (int)(line19.Location.X / scale) + drawStartPos;

            if (e.Control && e.KeyCode == Keys.L && csv.airGnd != "")
            {
                for (int i = a; i < CSVRowCount - 1; i++)
                {
                    int[] y = new int[2];

                    int.TryParse(CSV.Rows[i][csv.airGnd].ToString(), out y[0]);
                    int.TryParse(CSV.Rows[i + 1][csv.airGnd].ToString(), out y[1]);

                    if (y[0] == 1 && y[1] == 0)
                    {
                        schGraphPos.Value = i - pw;
                        break;
                    }
                }

                StatusBar();
                Application.DoEvents();

                DrawBM();
                ShowBM();
                WriteVal();
            }
            if (e.Control && e.KeyCode == Keys.T && csv.airGnd != "")
            {
                for (int i = a; i > 10; i--)
                {
                    int[] y = new int[2];

                    int.TryParse(CSV.Rows[i][csv.airGnd].ToString(), out y[0]);
                    int.TryParse(CSV.Rows[i + 1][csv.airGnd].ToString(), out y[1]);

                    if (y[0] == 0 && y[1] == 1)
                    {
                        schGraphPos.Value = i - pw;
                        break;
                    }
                }

                StatusBar();
                Application.DoEvents();

                DrawBM();
                ShowBM();
                WriteVal();
            }
            if (e.Control && e.KeyCode == Keys.Enter)
            {
                Pen lpen = new Pen(noteColor);
                lpen.Width = 2f;
                Font fnt = new Font("Tahoma", 8, FontStyle.Bold);
                SolidBrush b = new SolidBrush(noteColor);
                Graphics g;

                g = Graphics.FromImage(bmGraph);

                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                //g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                //g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBilinear;

                Point een = pnlGraph.PointToClient(Cursor.Position);
                Point twee = new Point(een.X, een.Y + 20);

                g.DrawEllipse(lpen, een.X - 10, een.Y - 10, 20, 20);
                g.DrawString(noteTextToolStripTextBox.Text, fnt, b, een.X + 15, een.Y);

                ShowBM();


            }
        }
        private class secondValues
        {
            public static double DME = 0;
            public static double[] windspeed = new double[] { 0, 0 };
            public static double radioAlt = 0;
        }
        private void pnlGraph_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                WriteVal();
            }
        }
        private void frmGraph_Load(object sender, System.EventArgs e)
        {
            pnlGraph.Width = ClientSize.Width;
            pnlGraph.Height = ClientSize.Height
                    - toolStrip.Height
                    - menuStrip1.Height
                    - statusStrip1.Height + 250;
            line19.Height = ClientSize.Height;
            bmGraph = new Bitmap(pnlGraph.Width, pnlGraph.Height, System.Drawing.Imaging.PixelFormat.Format24bppRgb);

            try
            {

                if (schGraphPos.Value == 0)
                {

                    CSV = DataToAnalyse.fdaDataTable;

                    CSVRowCount = CSV.Rows.Count;

                    schGraphPos.Maximum = CSVRowCount;
                    beginMerkerPosiesie = int.Parse(csv.sEXCcounter);
                    gotoCounter(beginMerkerPosiesie);

                }

                StatusBar();
                Application.DoEvents();
                stelToepModus();
                addWarningsToolDropDownItems();
                setScale();
                stelTekenWaardes();
                stelVinnigeKnopies();
                DrawBM();
                ShowBM();
                schGraphPos.SmallChange = (int)((pnlGraph.Width / scale) * 0.25);
                schGraphPos.LargeChange = (int)((pnlGraph.Width / scale) * 0.5);
            }
            catch
            { }
        }
        private void gotoCounter(int counter)
        {
            scale = trkScaleH.Value * 0.05;

            int derde = int.Parse(Math.Round(((pnlGraph.Width / scale) / 3), 0).ToString());


            for (int i = 0; i < CSVRowCount; i++)
            {
                double.TryParse(CSV.Rows[i][Parameters.rowCounter].ToString(), out double exPos);

                if (exPos == counter && i > derde)
                {
                    schGraphPos.Value = i - derde;
                    break;
                }
                else if (exPos > counter)
                {
                    break;
                }

            }
        }
        private void KryOpstygLandWaardes(double merkies, int tekenBegin)
        {
            int count = 0;

            if (!CSV.Columns.Contains(Parameters.airGround)
                && !CSV.Columns.Contains(Parameters.altitudePressure))
            {
                return;
            }

            int[] alt = new int[2];
            int[] ag = new int[2];

            for (int i = tekenBegin; i < CSVRowCount - 1 && count < merkies; i++)
            {
                count++;
                int.TryParse(CSV.Rows[i][Parameters.airGround].ToString(), out ag[0]);

                int.TryParse(CSV.Rows[i + 1][Parameters.airGround].ToString(), out ag[1]);

                if (ag[0] != ag[1])
                {
                    if (int.TryParse(CSV.Rows[i][Parameters.altitudePressure].ToString(), out opSkermHoogte))
                    { }
                    else
                    {
                        opSkermHoogte = -5000;
                    }
                    if (double.TryParse(CSV.Rows[i][Parameters.rowCounter].ToString(), out opSkermLandOpstuigMerker))
                    { }
                    else
                    {
                        opSkermLandOpstuigMerker = 0;
                    }
                }
            }

            skermHoogte.Text = opSkermHoogte.ToString() + " alt";
            skermAGMerker.Text = opSkermLandOpstuigMerker.ToString();

        }
        private void warningMenuItem_Click(object sender, System.EventArgs e)
        {
            DrawScale();
            DrawBM();
            ShowBM();
        }
        void b_Click(object sender, EventArgs e)
        {
            var knop = sender as ToolStripButton;

            for (int y = 0; y < p.Count; y++)
            {
                if (knop.Name.ToLower() == p[y].waardeOmTePlot.ToLower())
                {
                    p[y].teken = knop.Checked;
                    DrawBM();
                    ShowBM();
                    dataGridView1.DataSource = p;
                    return;
                }
            }
            dataGridView1.DataSource = p;

            //MessageBox.Show(button.Text + " " + button.Name, "die knoppie se text.");
        }
        private void mFileSave_Click(object sender, EventArgs e)
        {
            Save_Graph();
        }
        private void setStartCounterToolStripMenuItem_Click(object sender, EventArgs e)
        {

            try
            {
                Tools.StartCounter = huidigeCounter;
                beginCounter.Text = Tools.StartCounter.ToString();

            }
            catch (Exception xx)
            {
                MessageBox.Show("An error occurred in set start counter. " + xx, "Graph error.");
            }

        }
        private void setEndCounterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Tools.EndCounter = huidigeCounter;
                eindCounter.Text = Tools.EndCounter.ToString();

            }
            catch (Exception xx)
            {
                MessageBox.Show("An error occurred in set start counter. " + xx, "Graph error.");
            }
        }
        private void createKMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            double EventCounter = 0;
            createKML m = new createKML();
            double.TryParse(csv.sEXCcounter, out EventCounter);
            m.KMLEventCounter = Convert.ToInt32(EventCounter);

            if (Tools.StartCounter != 0)
            {
                m.StartCounter = Convert.ToInt32(Tools.StartCounter);
            }

            if (Tools.EndCounter != 0)
            {
                m.EndCounter = Convert.ToInt32(Tools.EndCounter);
            }

            m.Show();
        }
        private void showDistanceResultsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Distance " + Math.Round(FOQAData.Tools.Distance, 3) + " Km " + " Burn " + FOQAData.Tools.FU + " kg.", "Distance", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void savePositionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string result;
            userInput tes = new userInput();

            tes.ShowDialog();
            result = tes.resultText;


            tes.Dispose();

            MessageBox.Show(result, "Me input box waarde.");
        }
        private void Save_Graph()
        {
            Cursor.Current = Cursors.WaitCursor;
            string sPath = Application.StartupPath;

            try
            {
                if (bmGraph != null)
                {

                    saveFileDialog.InitialDirectory = "C:\\";
                    saveFileDialog.FileName = FOQAData.csv.csvFileName + "-" + FOQAData.csv.sExcID;
                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        bmGraph.Save(saveFileDialog.FileName, System.Drawing.Imaging.ImageFormat.Bmp);
                        MessageBox.Show("Done saving file.", sMessages.sMessage, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("File not saved!", sMessages.sMessage, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("There is noting to save.", sMessages.sMessage, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception xx)
            {
                MessageBox.Show(xx.ToString(), sMessages.sMessageError, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DrawBM();
                Cursor.Current = Cursors.Default;
            }
        }
        private void schGraphPos_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
        {
            if (e.Type == ScrollEventType.EndScroll)
            {
                StatusBar();
                DrawBM();
                ShowBM();
            }
        }
        private void schGraphPos_ValueChanged(object sender, System.EventArgs e)
        {

            StatusBar();
            DrawBM();
            ShowBM();

        }
        private void setScale()
        {
            bottomVal = pnlGraph.Height * 0.036f;
            topVal = pnlGraph.Height * 0.666666f;
            constant = bottomVal;
        }
        private void ShowBM()
        {
            Graphics objGraphics;
            objGraphics = pnlGraph.CreateGraphics();
            objGraphics.DrawImage(bmGraph, 0, 0, bmGraph.Width, bmGraph.Height);
            objGraphics.Dispose();
        }
        private void StatusBar()
        {
            Merker.Text = "- " + csv.sEXCcounter;
            Gebeurtenis.Text = "Exc " + csv.sExceedance;
            Gebeurtenis.ToolTipText = csv.sEXCnote;
        }
        private void stelTekenWaardes()
        {
            if (plotWaardesGestel)
            {
                return;
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.accelerationLongitudinalMax))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.accelerationLongitudinalMax,
                    kleur = Color.DarkBlue,
                    knopieNaam = "Acceleration Longitudenal max",
                    knopieNaamKort = "Aclx",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 4,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = false,
                    faktor = 1,
                    vinnigeKnopie = true
                });
            }


            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.accelerationLongitudinalMin))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.accelerationLongitudinalMin,
                    kleur = Color.Red,
                    knopieNaam = "Acceleration Longitudenal min",
                    knopieNaamKort = "Aclm",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 4,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = false,
                    faktor = 1,
                    vinnigeKnopie = true
                });
            }
            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.accelerationVerticalMin))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.accelerationVerticalMin,
                    kleur = Color.Red,
                    knopieNaam = "Acceleration vertical min",
                    knopieNaamKort = "Acvm",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 4,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = false,
                    faktor = 1,
                    vinnigeKnopie = true
                });
            }


            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.accelerationVerticalMax))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.accelerationVerticalMax,
                    kleur = Color.Lime,
                    knopieNaam = "Acceleration vertical max",
                    knopieNaamKort = "AcvX",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 4,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = false,
                    faktor = 1,
                    vinnigeKnopie = true
                });
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.airGround))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.airGround,
                    kleur = Color.Brown,
                    knopieNaam = "airGround",
                    knopieNaamKort = "AG",
                    breedte = 1,
                    posisie = bottomVal,
                    skuif = 0,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 1,
                    vinnigeKnopie = true
                });
            }


            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.attitudeRollLeft))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.attitudeRollLeft,
                    kleur = Color.Brown,
                    knopieNaam = "Attitude Roll",
                    knopieNaamKort = "ARl",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 4,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = false,
                    faktor = 10,
                    vinnigeKnopie = true
                });
            }

            p.Add(new PlotParameters
            {
                waardeOmTePlot = Parameters.altitudePressure,
                kleur = Color.Blue,
                knopieNaam = "Altitude Pressure",
                knopieNaamKort = "AltP",
                breedte = 1,
                posisie = bottomVal,
                skuif = 0,
                teken = true,
                tekenTipe = "grafiek",
                //tekenAanvanklik = true,
                faktor = 500,
                vinnigeKnopie = true
            });

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.attitudePitchLeft))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.attitudePitchLeft,
                    kleur = Color.Brown,
                    knopieNaam = "Attitude Pith",
                    knopieNaamKort = "APi",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 4,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = false,
                    faktor = 10,
                    vinnigeKnopie = true
                });
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.altitudeRadioLeft))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.altitudeRadioLeft,
                    kleur = Color.BlueViolet,
                    knopieNaam = "Altitude Radio",
                    knopieNaamKort = "AltR",
                    breedte = 1,
                    posisie = bottomVal,
                    skuif = 0,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 500,
                    vinnigeKnopie = true
                });
            }



            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.autoPilotA))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.autoPilotA,
                    kleur = Color.Brown,
                    knopieNaam = "Auto Pilot A",
                    knopieNaamKort = "APA",
                    breedte = 1,
                    posisie = bottomVal,
                    skuif = 9,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 1,
                    vinnigeKnopie = true
                });
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.autoPilotB))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.autoPilotB,
                    kleur = Color.Brown,
                    knopieNaam = "Auto Pilot B",
                    knopieNaamKort = "APB",
                    breedte = 1,
                    posisie = bottomVal,
                    skuif = 9,
                    teken = false,
                    tekenTipe = "grafiek",
                    faktor = 1,
                    vinnigeKnopie = true
                });
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.flapHandlePosition))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.flapHandlePosition,
                    kleur = Color.DarkMagenta,
                    knopieNaam = "Flap handle position",
                    knopieNaamKort = "fHDL",
                    breedte = 1,
                    posisie = bottomVal,
                    skuif = 0,
                    teken = false,
                    tekenTipe = "grafiek",
                    faktor = 5,
                    vinnigeKnopie = true
                });
            }

            p.Add(new PlotParameters
            {
                waardeOmTePlot = Parameters.flapTeLeft,
                kleur = Color.DarkCyan,
                knopieNaam = "Flap TE Left",
                knopieNaamKort = "fTE",
                breedte = 1,
                posisie = bottomVal,
                skuif = 0,
                teken = true,
                tekenTipe = "grafiek",
                faktor = 5,
                vinnigeKnopie = true
            });

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.fuelTankLeftQuantity))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.fuelTankLeftQuantity,
                    kleur = Color.Black,
                    knopieNaam = "fuel left tank",
                    knopieNaamKort = "fLt",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 0,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 5000,
                    vinnigeKnopie = true
                });
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.fuelTankCenterQuantity))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.fuelTankCenterQuantity,
                    kleur = Color.Black,
                    knopieNaam = "fuel centre tank",
                    knopieNaamKort = "fCt",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 0,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 5000,
                    vinnigeKnopie = true
                });
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.fuelTankRightQuantity))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.fuelTankRightQuantity,
                    kleur = Color.Black,
                    knopieNaam = "fuel right tank",
                    knopieNaamKort = "fRt",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 0,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 5000,
                    vinnigeKnopie = true
                });
            }



            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.grossWeight))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.grossWeight,
                    kleur = Color.Brown,
                    knopieNaam = "GrossWeight",
                    knopieNaamKort = "GW",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 0,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = false,
                    faktor = 50000,
                    vinnigeKnopie = true
                });
            }


            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.rowCounter))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.rowCounter,
                    kleur = Color.Black,
                    knopieNaam = "Counter",
                    knopieNaamKort = "co",
                    breedte = 1,
                    posisie = bottomVal,
                    skuif = 0,
                    teken = true,
                    tekenTipe = "waarde",
                    //tekenAanvanklik = true,
                    faktor = 500,
                    vinnigeKnopie = true
                });
            }
            // TODO skep parameter vir Vertikale afwyk van trajek
            //if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.))
            //{
            //    p.Add(new PlotParameters
            //    {
            //        waardeOmTePlot = Parameters.GMTtime,
            //        kleur = Color.Black,
            //        knopieNaam = "GMT",
            //        knopieNaamKort = "GMT",
            //        breedte = 1,
            //        posisie = bottomVal,
            //        skuif = 2,
            //        teken = false,
            //        tekenTipe = "waarde",
            //        //tekenAanvanklik = ,
            //        faktor = 1,
            //        vinnigeKnopie = true
            //    });
            //}

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.navDevGSLeft))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.navDevGSLeft,
                    kleur = Color.DarkBlue,
                    knopieNaam = "Glide Slope Dev",
                    knopieNaamKort = "GSd",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 4,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 0.1,
                    vinnigeKnopie = true
                });
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.navDevLocLeft))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.navDevLocLeft,
                    kleur = Color.SlateBlue,
                    knopieNaam = "Localiser Dev",
                    knopieNaamKort = "LOCd",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 4,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 0.1,
                    vinnigeKnopie = true
                });
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.navFreqLeft))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.navFreqLeft,
                    kleur = Color.DarkCyan,
                    knopieNaam = "Nav Freq Left",
                    knopieNaamKort = "fqL",
                    breedte = 1,
                    posisie = bottomVal,
                    skuif = 0,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 50,
                    vinnigeKnopie = true
                });
            }

            p.Add(new PlotParameters
            {
                waardeOmTePlot = Parameters.magneticHeadingLeft,
                kleur = Color.DeepPink,
                knopieNaam = "Magnetic Heading",
                knopieNaamKort = "HDG",
                breedte = 1,
                posisie = topVal,
                skuif = 0,
                teken = true,
                tekenTipe = "grafiek",
                //tekenAanvanklik = true,
                faktor = 50,
                vinnigeKnopie = true
            });

            p.Add(new PlotParameters
            {
                waardeOmTePlot = Parameters.speedCAS,
                kleur = Color.DarkCyan,
                knopieNaam = "CAS",
                knopieNaamKort = "CAS",
                breedte = 1,
                posisie = topVal,
                skuif = 0,
                teken = true,
                tekenTipe = "grafiek",
                //tekenAanvanklik = true,
                faktor = 50,
                vinnigeKnopie = true
            });

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.speedBrakeHandle))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.speedBrakeHandle,
                    kleur = Color.SteelBlue,
                    knopieNaam = "SpeedBrake",
                    knopieNaamKort = "SB",
                    breedte = 1,
                    posisie = bottomVal,
                    skuif = 0,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = -50,
                    vinnigeKnopie = true
                });
            }


            p.Add(new PlotParameters
            {
                waardeOmTePlot = Parameters.speedGround,
                kleur = Color.Black,
                knopieNaam = "GS",
                knopieNaamKort = "GS",
                breedte = 1,
                posisie = topVal,
                skuif = 0,
                teken = false,
                tekenTipe = "grafiek",
                //tekenAanvanklik = true,
                faktor = 50,
                vinnigeKnopie = true
            });

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.speedMach))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.speedMach,
                    kleur = Color.Red,
                    knopieNaam = "mach",
                    knopieNaamKort = "mach",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 0,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = false,
                    faktor = 0.5,
                    vinnigeKnopie = true
                });
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.speedV2))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.speedV2,
                    kleur = Color.Black,
                    knopieNaam = "V2",
                    knopieNaamKort = "V2",
                    breedte = 1,
                    posisie = topVal,
                    skuif = 0,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 50,
                    vinnigeKnopie = true
                });
            }


            p.Add(new PlotParameters
            {
                waardeOmTePlot = "DaalSpoed",
                kleur = Color.LimeGreen,
                knopieNaam = "Vertical speed calculated",
                knopieNaamKort = "VS",
                posisie = bottomVal,
                skuif = 7,
                teken = false,
                tekenTipe = "grafiek",
                //tekenAanvanklik = true,
                faktor = 500,
                vinnigeKnopie = true
            });



            Type t = typeof(JetEngineParameters);
            PropertyInfo[] pi = typeof(JetEngineParameters).GetProperties();
            Color[] colors = { Color.Brown, Color.Chocolate, Color.DarkGreen
                              ,Color.DarkKhaki, Color.IndianRed, Color.DarkSalmon
                              ,Color.DarkSlateGray, Color.DarkGray, Color.Black
                              ,Color.DarkMagenta, Color.DarkSlateBlue, Color.Blue};
            int count = 0;

            for (int i = 0; i < Parameters.JetEngineParameters.Count; i++)
            {
                if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.JetEngineParameters[i].bleed))
                {
                    p.Add(new PlotParameters
                    {
                        waardeOmTePlot = Parameters.JetEngineParameters[i].bleed,
                        kleur = Color.Black,
                        knopieNaam = "bleed " + (i + 1),
                        knopieNaamKort = "b " + (i + 1),
                        breedte = 1,
                        posisie = topVal,
                        skuif = 0,
                        teken = false,
                        tekenTipe = "grafiek",
                        //tekenAanvanklik = true,
                        faktor = 50,
                        vinnigeKnopie = true
                    });
                    count++;
                }

                if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.JetEngineParameters[i].egt))
                {
                    p.Add(new PlotParameters
                    {
                        waardeOmTePlot = Parameters.JetEngineParameters[i].egt,
                        kleur = colors[count],
                        knopieNaam = "EGT " + Parameters.JetEngineParameters[i].egt,
                        knopieNaamKort = "EGT " + (i + 1),
                        breedte = 1,
                        posisie = topVal,
                        skuif = 0,
                        teken = false,
                        tekenTipe = "grafiek",
                        //tekenAanvanklik = true,
                        faktor = 500,
                        vinnigeKnopie = true
                    });
                    count++;
                }

                if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.JetEngineParameters[i].N1))
                {
                    p.Add(new PlotParameters
                    {
                        waardeOmTePlot = Parameters.JetEngineParameters[i].N1,
                        kleur = colors[count],
                        knopieNaam = "N1 " + Parameters.JetEngineParameters[i].N1,
                        knopieNaamKort = "N1 " + (i + 1),
                        breedte = 1,
                        posisie = topVal,
                        skuif = 0,
                        teken = false,
                        tekenTipe = "grafiek",
                        //tekenAanvanklik = true,
                        faktor = 50,
                        vinnigeKnopie = true
                    });
                    count++;
                }

                if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.JetEngineParameters[i].N2))
                {
                    p.Add(new PlotParameters
                    {
                        waardeOmTePlot = Parameters.JetEngineParameters[i].N2,
                        kleur = colors[count],
                        knopieNaam = "N2 " + Parameters.JetEngineParameters[i].N2,
                        knopieNaamKort = "N2 " + (i + 1),
                        breedte = 1,
                        posisie = topVal,
                        skuif = 0,
                        teken = false,
                        tekenTipe = "grafiek",
                        //tekenAanvanklik = true,
                        faktor = 50,
                        vinnigeKnopie = true
                    });
                    count++;
                }
                if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.JetEngineParameters[i].oilPressure))
                {
                    p.Add(new PlotParameters
                    {
                        waardeOmTePlot = Parameters.JetEngineParameters[i].oilPressure,
                        kleur = colors[count],
                        knopieNaam = "OP " + Parameters.JetEngineParameters[i].oilPressure,
                        knopieNaamKort = "OP " + (i + 1),
                        breedte = 1,
                        posisie = topVal,
                        skuif = 0,
                        teken = false,
                        tekenTipe = "grafiek",
                        //tekenAanvanklik = true,
                        faktor = 10,
                        vinnigeKnopie = true
                    });
                }

                if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.JetEngineParameters[i].oilTemp))
                {
                    p.Add(new PlotParameters
                    {
                        waardeOmTePlot = Parameters.JetEngineParameters[i].oilTemp,
                        kleur = colors[count],
                        knopieNaam = "OT " + Parameters.JetEngineParameters[i].oilTemp,
                        knopieNaamKort = "OT " + (i + 1),
                        breedte = 1,
                        posisie = topVal,
                        skuif = 0,
                        teken = false,
                        tekenTipe = "grafiek",
                        //tekenAanvanklik = true,
                        faktor = 10,
                        vinnigeKnopie = true
                    });
                }

                if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.JetEngineParameters[i].fuelLever))
                {
                    p.Add(new PlotParameters
                    {
                        waardeOmTePlot = Parameters.JetEngineParameters[i].fuelLever,
                        kleur = colors[count],
                        knopieNaam = "FL " + Parameters.JetEngineParameters[i].fuelLever,
                        knopieNaamKort = "EFL " + (i + 1),
                        breedte = 1,
                        posisie = topVal,
                        skuif = 0,
                        teken = false,
                        tekenTipe = "grafiek",
                        //tekenAanvanklik = true,
                        faktor = 1,
                        vinnigeKnopie = true
                    });
                }
                count++;

            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.gearLeverDown))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.gearLeverDown,
                    kleur = Color.Black,
                    knopieNaam = "Gear lever Down",
                    knopieNaamKort = "GLD",
                    breedte = 1,
                    posisie = bottomVal,
                    skuif = 1,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 1,
                    vinnigeKnopie = true
                });
            }
            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.gearUpLeft))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.gearUpLeft,
                    kleur = Color.DarkBlue,
                    knopieNaam = "Gear up left",
                    knopieNaamKort = "GUL",
                    breedte = 1,
                    posisie = bottomVal,
                    skuif = 2,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 1,
                    vinnigeKnopie = true
                });
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.windDirection))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.windDirection,
                    kleur = Color.DarkBlue,
                    knopieNaam = "Wind direction",
                    knopieNaamKort = "WD",
                    breedte = 1,
                    posisie = bottomVal,
                    skuif = 0,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 50,
                    vinnigeKnopie = true
                });
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.windVelocity))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.windVelocity,
                    kleur = Color.DarkMagenta,
                    knopieNaam = "Wind velocity",
                    knopieNaamKort = "WS",
                    breedte = 1,
                    posisie = bottomVal,
                    skuif = 0,
                    teken = false,
                    tekenTipe = "grafiek",
                    //tekenAanvanklik = true,
                    faktor = 50,
                    vinnigeKnopie = true
                });
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.GMTtime))
            {
                p.Add(new PlotParameters
                {
                    waardeOmTePlot = Parameters.GMTtime,
                    kleur = Color.Black,
                    knopieNaam = "GMT",
                    knopieNaamKort = "GMT",
                    breedte = 1,
                    posisie = bottomVal,
                    skuif = 2,
                    teken = false,
                    tekenTipe = "waarde",
                    //tekenAanvanklik = ,
                    faktor = 1,
                    vinnigeKnopie = true
                });
            }



            dataGridView1.DataSource = p;
            plotWaardesGestel = true;
        }
        private void stelToepModus()
        {
            if (appSettings.Mode.ToLower() == "demo")
            {

                Datum.Visible = false;
                vlugNommer.Visible = false;
            }
            else if (appSettings.Mode.ToLower() == "dev")
            {
                Datum.Visible = true;
                vlugNommer.Visible = true;
            }

        }
        private void stelVinnigeKnopies()
        {
            if (vinnigeKnoppiesGestel)
            {
                return;
            }
            for (int i = 0; i < p.Count; i++)
            {
                if (p[i].vinnigeKnopie == true)
                {
                    ToolStripButton b = new ToolStripButton();
                    b.Name = p[i].waardeOmTePlot;
                    b.Text = p[i].knopieNaamKort;
                    b.Checked = p[i].teken;
                    b.CheckOnClick = true;
                    b.Click += b_Click;
                    b.ToolTipText = p[i].knopieNaam;
                    toolStrip.Items.Add(b);
                }
            }

            positionOnGoogle.Enabled = CSV.Columns.Contains(Parameters.latitude);
            vinnigeKnoppiesGestel = true;
        }
        private void trkScaleH_ValueChanged(object sender, System.EventArgs e)
        {
            schGraphPos.SmallChange = (int)((pnlGraph.Width / scale) * 0.15);
            schGraphPos.LargeChange = (int)((pnlGraph.Width / scale) * 0.5);
            DrawBM();
            ShowBM();
        }
        private void noteCoulorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                noteColor = colorDialog.Color;
            }
        }
        private void showGraphParametersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Visible)
            {
                dataGridView1.Visible = false;
            }
            else
            {
                dataGridView1.Visible = true;
            }
            DrawBM();
            ShowBM();
            WriteVal();
        }
        private static class cValue
        {
            public static double dExceednaceLatitude = 0;
            public static double dExceedanceLongitude = 0;
        }

        private void positionOnGoogle_Click(object sender, EventArgs e)
        {
            GoogleWysPosisie(Convert.ToDouble(CSV.Rows[iPos][Parameters.latitude]), Convert.ToDouble(CSV.Rows[iPos][Parameters.longitude]));
        }

        private void GoogleWysPosisie(double latitude, double longitude)
        {
            if (iPos == 0)
            {
                MessageBox.Show("No position to draw.", "Flight View", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            StringBuilder sGoogleViewLatLong = new StringBuilder();
            sGoogleViewLatLong.Append("http://maps.google.com/maps?q=");
            sGoogleViewLatLong.Append(latitude.ToString() + "," + longitude.ToString());
            System.Diagnostics.Process.Start(sGoogleViewLatLong.ToString());

        }

        private void WriteVal()
        {

            float fHeight = pnlGraph.Height;
            DateTime FlightDate;

            Point po = this.PointToClient(Cursor.Position);

            line19.Location = new Point(po.X - 3, 0); // x was minus 3

            iPos = (int)(po.X / scale) + drawStartPos;

            if (iPos > CSV.Rows.Count - 10 || iPos < 10)
            {
                return;
            }
            #region werk nie nou met die nie
            #region Flight details

            if (CSV.Columns.Contains(Parameters.flightNumber))
            {
                vlugNommer.Text = "# " + Convert.ToString(CSV.Rows[iPos][Parameters.flightNumber]);
            }
            else
            {
                vlugNommer.Text = "nill";
            }

            if (DataToAnalyse.fdaDataTable.Columns.Contains(Parameters.GMTdate))
            {
                //string s = 
                Datum.Text = CSV.Rows[iPos][Parameters.GMTdate].ToString();

                //if (s.Length == 6)
                //{
                //    s = "20" + s.Substring(0,2) + "-" + s.Substring(2,2) + "-" + s.Substring(4, 2);
                //}

                //if (DateTime.TryParse(s, out FlightDate))
                //{
                //    Datum.Text = FlightDate.Date.ToString("dd-MMM-yy");
                //}

                ////if (DateTime.TryParse(CSV.Rows[iPos][Parameters.GMTdate].ToString(), out FlightDate))
                ////{
                ////    Datum.Text = FlightDate.Date.ToString("dd-MMM-yy");
                ////}
                //else
                //{
                //    Datum.Text = " - ";
                //}

            }
            else
            {
                Datum.Text = "No date";
            }
            #endregion

            //#region Alt VS

            //double alt = 0;

            //#endregion

            #endregion

            if (CSV.Columns.Contains(Parameters.rowCounter) && double.TryParse(CSV.Rows[iPos][Parameters.rowCounter].ToString(), out double y))
            {
                BerekenAfstandPerSekMetode(y, iPos);
            }

            Font fnt = new Font("Calibri", 10, FontStyle.Bold);
            SolidBrush bsl = new SolidBrush(Color.Red);
            Point point = new Point();
            float spasie = (float)(fHeight * 0.036);
            float tweede = (pnlGraph.Height * 0.66666f);
            int waardeWatGeplotMoetWordTel = 0;

            int tekenParameters = 0;
            
            for (int i = 0; i < p.Count; i++)
            {
                if (p[i].teken)
                {
                    tekenParameters++;
                }
            }
            
            List <TekenWaardes> tw = new List<TekenWaardes>();

            tekenParameters = 0;

            for (int i = 0; i < p.Count; i++)
            {
                if (p[i].teken && p[i].tekenTipe == "grafiek")
                {
                    string tekenWaarde = "";
                    double x;

                    if (p[i].waardeOmTePlot.ToLower() == "daalspoed")
                    {
                        double.TryParse(CSV.Rows[iPos - 3][Parameters.altitudePressure].ToString(), out double een);//die twee is nuut
                        double.TryParse(CSV.Rows[iPos + 3][Parameters.altitudePressure].ToString(), out double twee);
                        x = (twee - een) * 10;
                        tekenWaarde = x.ToString();

                    }
                    else if (p[i].waardeOmTePlot.ToLower() == Parameters.altitudePressure.ToLower())
                    {
                        if (double.TryParse(CSV.Rows[iPos][p[i].waardeOmTePlot].ToString(), out x))
                        {

                            tekenWaarde = x.ToString() + " [" + (x - opSkermHoogte).ToString() + "]";
                        }
                        else
                        {
                            //x = 0;
                            tekenWaarde = "|";
                        }
                    }
                    else
                    {
                        if (double.TryParse(CSV.Rows[iPos][p[i].waardeOmTePlot].ToString(), out x))
                        {
                            tekenWaarde = x.ToString();
                        }
                        else
                        {
                            tekenWaarde = "|";
                        }

                    }

                    point.X = po.X + 2;

                    point.Y = (int)(fHeight - (p[i].posisie + (constant * (x / p[i].faktor)))) - 15;

                    point.Y -= (int)(p[i].skuif * constant);

                    tw.Add(new TekenWaardes() {
                         waardeKleur = p[i].kleur
                        ,waardeNaam = p[i].knopieNaamKort
                        ,waardeOmTeKsryf = tekenWaarde
                        ,tekenPosiesie = point.Y});
                 
                    tekenParameters++;
                    
                }

                if (p[i].teken && p[i].tekenTipe == "waarde")
                {
                    //bsl.Color = p[i].kleur;

                    if (p[i].waardeOmTePlot.ToLower() == Parameters.rowCounter.ToLower())
                    {
                        huidigeCounter = double.Parse(CSV.Rows[iPos][p[i].waardeOmTePlot].ToString());
                    }

                    string s = CSV.Rows[iPos][p[i].waardeOmTePlot].ToString();
                    point.X = po.X + 2;
                    point.Y = (int)(fHeight - (fHeight * 0.64f));
                    point.Y -= waardeWatGeplotMoetWordTel * 13;

                    tw.Add(new TekenWaardes()
                    {
                         waardeKleur = p[i].kleur
                        ,waardeNaam = p[i].knopieNaamKort
                        ,waardeOmTeKsryf = s
                        ,tekenPosiesie = point.Y
                    });

                    waardeWatGeplotMoetWordTel += 1;
                    tekenParameters++;
                }

            }

            // sprei waardes wat geteken word.
            SpryTekenWaardes(tw, 11);

            //skryf die waardes
            //todo sit die x waarde by wat geplot moet word en dan kan hulle hier geteken word.

            for (int w = 0; w < tw.Count; w++)
            {
                point.Y = tw[w].tekenPosiesie;
                bsl.Color = tw[w].waardeKleur;

                pnlGraph.CreateGraphics().DrawString(tw[w].waardeOmTeKsryf + " " + tw[w].waardeNaam, fnt, bsl, point);
            }

            iCount += 1;

            if (iCount == 3)
            {
                ShowBM();
                iCount = 0;
            }
        }
       
        private static List<TekenWaardes> SpryTekenWaardes(List<TekenWaardes> tw, int spasie)
        {
  
            tw.Sort();

            for (int i = 0; i < tw.Count - 1; i++)
            {

                if (Math.Abs(tw[i].tekenPosiesie - tw[i + 1].tekenPosiesie) <= spasie)

                {
                    int z = 0;
                    do
                    {
                        if (tw[i + 1].tekenPosiesie - tw[i].tekenPosiesie <= 0)
                        {
                            tw[i + 1].tekenPosiesie = tw[i].tekenPosiesie + spasie;
                            z++;
                        }
                        else if (tw[i + 1].tekenPosiesie == tw[i].tekenPosiesie)// maak seker as die waardes verskillend is dat die waardes gesprei word
                        {
                            tw[i + 1].tekenPosiesie += spasie;
                            z++;
                        }
                        else
                        {
                            tw[i + 1].tekenPosiesie += (spasie - Math.Abs(tw[i + 1].tekenPosiesie - tw[i].tekenPosiesie));
                            z++;
                        }

                    } while (tw[i + 1].tekenPosiesie - tw[i].tekenPosiesie < spasie && i < tw.Count && i > 0 && z < tw.Count);
                }
            }

            return tw;
        }
        
    }

    public class TekenWaardes : IComparable<TekenWaardes>
    {
        public Color waardeKleur { get; set; }
        public string waardeNaam { get; set; }
        public int tekenPosiesie { get; set; }
        public string waardeOmTeKsryf { get; set; }

        public int CompareTo(TekenWaardes other)
        {
            return this.tekenPosiesie.CompareTo(other.tekenPosiesie);
        }
    }

}





